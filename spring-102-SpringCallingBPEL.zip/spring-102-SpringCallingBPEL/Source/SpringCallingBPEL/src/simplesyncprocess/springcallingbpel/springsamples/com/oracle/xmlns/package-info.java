@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/SpringSamples/SpringCallingBPEL/SimpleSyncProcess", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package simplesyncprocess.springcallingbpel.springsamples.com.oracle.xmlns;
