package com.oracle.soa.samples.spring;

public interface IHelloWorld {
    
    public String greetUser(String userName);
}
