package com.oracle.soa.samples.spring;

import simplesyncprocess.springcallingbpel.springsamples.com.oracle.xmlns.ObjectFactory;
import simplesyncprocess.springcallingbpel.springsamples.com.oracle.xmlns.ProcessResponse;
import simplesyncprocess.springcallingbpel.springsamples.com.oracle.xmlns.SimpleSyncProcess;

public class HelloWorld implements IHelloWorld {
    
    //Step 1:declare a member variable with the same name as the property declared in the Spring context XML
    //Following this, generate getter and setter accessor functions for this variable.
    SimpleSyncProcess calledService;
    public HelloWorld() {
        super();
    }
    //Step 2a: declare setter for the member variable
    public void setCalledService(SimpleSyncProcess calledService) {
        this.calledService = calledService;
    }
    //Step 2b: delcare getter for the member variable
    public SimpleSyncProcess getCalledService() {
        return calledService;
    }
    //Step 3:After you define the property variable and it's accessors, create
    public String greetUser(String userName) {
        
        //Step a: Prepare the input Payload
        ObjectFactory factory = new ObjectFactory();
        simplesyncprocess.springcallingbpel.springsamples.com.oracle.xmlns.Process input = factory.createProcess();
        input.setInput(userName);
        //Step b: Invoke the Service, which in turns invokes the BPEl Process
        ProcessResponse response = calledService.process(input);
        //Step c: Process the response from the BPEL and return the field within
        //the response. Note that here, "result" is just an element witihn the 
        //response element.
        return response.getResult();
    }

}
